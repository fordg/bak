<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Msize extends CI_Model{
    public function __construct(){
        parent::__construct();
    }
     public function record_count() {
        return $this->db->count_all("size");
    }
     public function tambahin($data){
         
         $this->db->query("insert into ukuran (ukuran) values ('ukuran_$data')");
         $this->db->query("ALTER TABLE  `produk`  ADD  `ukuran_$data`  INT NOT NULL");
                  
      return $this->db->_error_number();
     }

     public function update_record($id,$data,$data_lama){
      $query = $this->db->query("UPDATE ukuran SET ukuran = 'ukuran_$data' WHERE id = '$id'");
        $this->db->query("ALTER TABLE  `produk` CHANGE  `$data_lama`  `ukuran_$data` INT( 11 ) NOT NULL");
       
      

      return $query;
     }

     public function delete_row($data){
      $this->db->where('ukuran', $data);
      $this->db->delete('ukuran');
        $this->db->query("ALTER TABLE  `produk`  DROP  `$data`");
        
     }
     public function caridata(){
        $c = $this->input->post('search');
        $this->db->like('namasize', $c);
        $query = $this->db->get ('size');
        return $query->result(); 
     }
     public function tampil(){
    //$this->db->from('mahasiswa');
        $query = $this->db->get('ukuran');
        return $query->result_array(); 
     }
     public function get_id ($id){
        $sql= "select id,ukuran from ukuran where id = '".$id. "'";
        return $this->db->query($sql)->row();
    }
    public function get_distinc(){
        $sql= "SELECT * FROM ukuran";
        return $this->db->query($sql)->result();
    }
}