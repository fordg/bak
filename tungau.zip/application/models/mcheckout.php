<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Mcheckout extends CI_Model{
    public function __construct(){
        parent::__construct();
    }
      public function masukin($table,$data){
      $this->db->insert($table, $data);  
     }
     
     public function teang(){
          date_default_timezone_set('Asia/Jakarta');
          
         $now= date("ymd");
         $nso= date("Y-m-d");   
         $g=$this->db->query("select kode_transaksi from pemesanan where SUBSTRING(waktu,1,10) = '$nso' order by kode_transaksi desc limit 0,1")->result(); 
                              if( sizeof($g)==0)
                              {
                                 $no=$now."001";
                               }
                               else
                                    { 
                                $no=substr($g[0]->kode_transaksi,9,strlen($g[0]->kode_transaksi)-9);
                                $no=$now.$no+1; 
                                    } 
                                   return  $no;
           
     }
     
      public function kurangin_stok_dong_bro($ukurin,$qty,$kodprod){
           $g=$this->db->query("UPDATE produk SET $ukurin = $ukurin - " . $qty  . " WHERE kodeproduk = '" . $kodprod."'"); 
       
        ;
    }
    
     public function history_order($id){ 
        
        $sql= "select * from pemesanan where id_member = '".$id. "'";
        return $this->db->query($sql)->result();
     }
     
     public function daftar_bank()
     {
        return $this->db->get('bank')->result();
        
     }
     
}