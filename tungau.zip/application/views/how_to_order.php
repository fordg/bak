<div class="container">
<section class="page">
	<div class="row">
    	<header class="span12 prime">
			<h3>How to Order</h3>
		</header>
		<div class="span12">
			<p>
            	<ul>
                	<li type="1">
                    	Login / Buat Akun Baru di babyandkids.com
                        <ul>
                        	<li>
                            	Klik Login pada bagian header web http://www.babyandkids.com .
                                <img src="<?php echo base_url(); ?>img/tai/login.JPG" />
                            </li>
                            <li>Isi data lengkap diri anda, setelah itu klik Register.</li>
                            <li>
                            	Jika sudah mendaftarkan diri anda, login dengan username dengan password yang sesuai.
                            	<img src="<?php echo base_url(); ?>img/tai/login 2.JPG" />
                            </li>
                        </ul>
                    </li>
                    <li type="1">
                    	Memilih Produk yang Akan Dibeli
                        <ul>
                        	<li>Pilih produk yang akan beli.</li>
                            <li>
                            	Klik View untuk melihat detail produk. <br />
                                <img src="<?php echo base_url();?>img/tai/des.JPG" />
                            </li>
                            <li>Pilih ukuran pakaian terlebih dahulu yang Anda inginkan.</li>
                            <li>Isi jumlah produk yang ingin Anda beli, setelah itu klik Add to cart.</li>
                            <li>
                            	Jika Anda sudah meng-klik Add to cart maka tampil list produk yang Anda beli, apabila selesai membeli produk klik Checkout.
                            	<img src="<?php echo base_url(); ?>img/tai/cart.JPG" />
                            </li>
                        </ul>
                    </li>
                </ul>
            </p>
		</div><!-- end span12 -->
	</div><!-- end row -->
</section>
</div>