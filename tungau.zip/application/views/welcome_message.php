<?php 
//echo( $curel);
?>