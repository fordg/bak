<?php echo $validate ?>

<!-- content -->
		<div id="content">
			<!-- end content / left -->
			<div id="left">
				<div id="menu">
					<h6 id="h-menu-products" class="selected"><a href="#products"><span>Products</span></a></h6>
					<ul id="menu-products" class="opened">
						<li><a href="<?php echo base_url(); ?>admin/produk">Manage Products</a></li>
						<li><a href="<?php echo base_url(); ?>admin/produk/add">Add Product</a></li>
					</ul>
					<h6 id="h-menu-member"><a href="#member"><span>Member</span></a></h6>
					<ul id="menu-member" class="closed">
						<li><a href="<?php echo base_url(); ?>admin/member">Manage Member</a></li>
					</ul>
					<h6 id="h-menu-events"><a href="#events"><span>Events</span></a></h6>
					<ul id="menu-events" class="closed">
						<li><a href="">Manage Events</a></li>
						<li class="last"><a href="">New Event</a></li>
					</ul>
					<h6 id="h-menu-links"><a href="#links"><span>Category</span></a></h6>
					<ul id="menu-links" class="closed">
						<li><a href="<?php echo base_url(); ?>admin/category">Manage Category</a></li>
					    <li class="last"><a href="<?php echo base_url(); ?>admin/category/add">Add Category</a></li>
					</ul>
                    <h6 id="h-menu-size"><a href="#size"><span>Size</span></a></h6>
					<ul id="menu-size" class="closed">
						<li><a href="<?php echo base_url(); ?>admin/size">Manage Size</a></li>
                      	<li><a href="<?php echo base_url(); ?>admin/size/add_size">Add New Size</a></li>
	
					</ul>
                    
                    <h6 id="h-menu-bank"><a href="#bank"><span>Bank</span></a></h6>
					<ul id="menu-bank" class="closed">
						<li><a href="<?php echo base_url(); ?>admin/bank/manage">Manage Bank</a></li>
                      	<li><a href="<?php echo base_url(); ?>admin/bank/add_data">Add New Bank</a></li> 
					</ul>
                    
                     <h6 id="h-menu-jasa"><a href="#jasa"><span>Jasa</span></a></h6>
					<ul id="menu-jasa" class="closed">
						<li><a href="<?php echo base_url(); ?>admin/jasa/manage/jasa_pengiriman">Manage Jasa Pengiriman</a></li> 
                      	<li><a href="<?php echo base_url(); ?>admin/jasa/add_data/jasa_pengiriman">Add New Jasa Pengiriman</a></li>
						<li><a href="<?php echo base_url(); ?>admin/jasa/manage/paket_jasa">Manage Paket Jasa </a></li> 
                        <li><a href="<?php echo base_url(); ?>admin/jasa/add_data/paket_jasa">Add New Paket Jasa</a></li>
						<li><a href="<?php echo base_url(); ?>admin/ongkir/manage/ongkos_kirim">Manage Ongkir</a></li> 
                        <li><a href="<?php echo base_url(); ?>admin/ongkir/add_data/">Add New Ongkos kirim</a></li>
	                    <li><a href="<?php echo base_url(); ?>admin/ongkir/upload/ongkos_kirim">Upload Excel Ongkir</a></li>
	
					</ul>
                     <h6 id="h-menu-pemesanan"><a href="#pemesanan"><span>Pemesanan</span></a></h6>
					<ul id="menu-pemesanan" class="closed">
						<li><a href="<?php echo base_url(); ?>admin/pemesanan/index">Manage Pemesanan</a></li>  
	
					</ul>
                    
					<h6 id="h-menu-settings"><a href="#settings"><span>Settings</span></a></h6>
					<ul id="menu-settings" class="closed">
						<li><a href="">Manage Settings</a></li>
						<li class="last"><a href="">New Setting</a></li>
					</ul>
				</div>
				<div id="date-picker"></div>
			</div>
			<!-- end content / left -->
			<!-- content / right -->
			<div id="right">
				<!-- table -->
				<div class="box">
					<!-- box / title -->
					<div class="title">
						<h5>Tambah Kategori</h5>
						<!--div class="search">
							<form action="<?php echo base_url(); ?>admin/category/cari" method="post">
								<div class="input">
									<input type="text" id="search" name="search" />
								</div>
								<div class="button">
									<input type="submit" name="submit" value="Search" />
								</div>
							</form>
						</div-->
					</div>
					<!-- end box / title -->
                    <?php echo $this->session->flashdata('message');?>
                                        <div class="table">
                    <?php echo form_open(base_url().'admin/jasa/tambah_'); ?>
                    <table style="width:450px">
							<thead>
								<tr>
									<th colspan="2" class="left">Administrator Information Update</th>
								</tr>
							</thead>
							<tbody>
                             <tr> 
                            <td>Nama Jasa Pengiriman</td>
                            <td>
                            <select name="id_jasa_pengiriman" id="id_jasa_pengiriman">
                             <option disabled="disabled" selected="selected" value="0">-Pilih Jasa Pengiriman-</option>
                             <?php foreach($jasa_pengiriman as $value) {?>
                             <option value="<?php echo $value['id_jasa_pengiriman']; ?>">
							<?php echo $value['nama_jasa_pengiriman'] ?>
                            </option>
                            <?php } ?>
                            </select> 
                            </td>
                            </tr>
								<tr>
									<td width="219" class="title">Nama Paket Jasa</td>
								  <td width="219" class="price" style="text-align:left;">
								  	<?php echo form_input(array('id'=>'nama_paket_jasa','name'=>'nama_paket_jasa','size'=>'40')); ?>                                  </td>
						 <input type="hidden" name="tabel" value="paket_jasa" />
                         	  </tr>
								<tr>
									<td colspan="2" class="title" style="text-align:center">
                                    <?php echo form_submit(array('value'=>'simpan')); ?>                                    </td>
								</tr>
							</tbody>
						</table>
                      <?php echo form_close(); ?>
				  </div>
			  </div>
				<!-- end table -->
			  <!-- messages -->
			  <!-- end messages -->
			  <!-- forms -->
			  <!-- end forms -->
			  <!-- box / left --><!-- end box / left -->
				<!-- box / right -->
              <!-- end box / right -->
		    </div>
			<!-- end content / right -->
		</div>
		<!-- end content -->