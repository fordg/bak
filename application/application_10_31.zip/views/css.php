<link rel="stylesheet" href="<?php echo base_url(); ?>css/bootstrap.min.css" />
<link rel="stylesheet" href="<?php echo base_url(); ?>css/font.css" />
<link rel="stylesheet" href="<?php echo base_url(); ?>css/style.css" />
<link rel="icon" href="<?php echo base_url(); ?>img/logo.png">