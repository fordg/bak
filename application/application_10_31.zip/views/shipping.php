<div class="container">
	<section class="page">
		<div class="row">
			<header class="span12 prime">
				<h3>Shipping Policy</h3>
			</header>
		</div>

		<div class="wrap">
			<div class="row-fluid">
				<div class="span12">
					<h5>Shipping Policy</h5>
                    <p>
                    	1. Setelah anda melakukan order dan menerima konfirmasi pembayaran harap segera transfer.<br />
                        2. Batas Waktu transfer adalah jam 20.00 WIB. Apabila kami tidak menerima transfer dari anda maka pesanan Anda kami anggap batal.<br />
                        3. Setelah melakukan transfer, harap infokan kepada kami via email/sms/BBM. Kami akan mengirim barang anda dihari berikutnya.<br />
                    </p>
                    <h5>Jadwal Pengiriman</h5>
                    <p>
                    	1. Pengiriman akan dilakukan sehari sesudahnya.<br />
                        2. Jadwal pickup service TIKI setiap hari Senin - Sabtu jam 9 pagi.<br />
                        3. Apabila anda transfer pada hari Sabtu/Minggu, akan dikirim hari Senin.<br /> 
                    </p>	
				</div>
			</div>
		</div>
	</section>
</div>