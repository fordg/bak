<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Msize extends CI_Model{
    public function __construct(){
        parent::__construct();
    }
     public function record_count() {
        return $this->db->count_all("size");
    }
     public function tambahin($data){
      
       $query=$this->db->insert('ukuran',$data);         
       $iiid=$this->db->insert_id();
     $this->db->query("ALTER TABLE  `produk`  ADD  `ukr_$iiid`  INT NOT NULL");
      return $this->db->_error_number();
                  
      }

     public function update_record($id,$data){
      $query = $this->db->query("UPDATE ukuran SET ukuran_produk = '$data' WHERE id = '$id'");
      }

     public function delete_row($id){ 
        $idii="ukr_".$id;
        $this->db->query("delete from ukuran WHERE id = '$id'");
        $this->db->query("ALTER TABLE  `produk`  DROP  `$idii`");
        
     }
    
     public function tampil(){
        $query = $this->db->get('ukuran');
        return $query->result_array(); 
     }
     public function get_id ($id){
        $sql= "select u.*,k.namaKategori from ukuran u,kategori k where k.id_kategori=u.id_kategori and u.id = '".$id. "'";
        return $this->db->query($sql)->row();
    }
     public function yang_id_kategorinya ($id){
        $sql= "select * from ukuran where id_kategori = '".$id. "'";
        return $this->db->query($sql)->result_array();
    }
            
}