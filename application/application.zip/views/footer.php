<footer>
	<div class="container">
		<section class="row foot">
            <article class="span3">
                <strong>Links</strong>
                <ul>
                    <li><a href="#">Tentang Kami</a></li>
                    <?php /* <li><a href="<?php echo base_url(); ?>privacy_policies">Returns Policies</a></li> */ ?>
                    <!--<li><a href="#">News</a></li>-->
                    <li><a href="mailto:babyandkids_shop@yahoo.com">Feedback</a></li>
                    <li><a href="<?php echo base_url(); ?>contact">Kontak</a></li>
                </ul>
            </article>
            <article class="span3">
                <strong>Pelanggan</strong>
                    <ul>
                        <li><a href="<?php echo base_url(); ?>login">Login</a></li>
                        <li><a href="<?php echo base_url(); ?>register">Daftar Member</a></li>
                        <li><a href="<?php echo base_url(); ?>shipping">Pengiriman</a></li>
                        <li><a href="<?php echo base_url(); ?>rexchanges">Pengembalian</a></li>
                    </ul>
            </article>
            <article class="span3">
            	<strong>Toko</strong>
                <address class="row-fluid">
                    <!-- <div class="pull-left clabel"><i class="icon-phone"></i></div> -->
                    <div class="pull-left cdata">Telepon : +628999903407</div>
                </address>
                <address class="row-fluid">
                    <!-- <div class="pull-left clabel"><i class="icon-location"></i></div> -->
                    <div class="pull-left cdata">PIN BB : 3140C680</div>
                </address>
                <address class="row-fluid">
                    <!-- <div class="pull-left clabel"><i class="icon-chart-pie"></i></div> -->
                    <div class="pull-left cdata">09.00 - 17.00 <br />(Senin - Sabtu)</div>
                </address>					
            </article>
            <article class="span3">
                <strong>Support Chat</strong>
                   	<a href="ymsgr:SendIM?Babyandkids_shop"><img alt="" src="http://opi.yahoo.com/online?u=Babyandkids_shop&amp;m=g&amp;t=14" border="0" /></a>
			</article>
		</section>
				
		<section class="row-fluid doubleline">
			<div class="span6">
				<div class="payment amex"></div>
				<div class="payment mastercard"></div>
				<div class="payment visa"></div>
				<div class="payment paypal"></div>
			</div>
		</section>
		
		<section class="row-fluid social">
			<div class="pull-left">&copy; 2013 BabyandKids-Shop All Rights Reserved</div>
			<div class="pull-right" style="text-align:right">
            	Redesigned and Developed by <a href="https://twitter.com/web9raph">Web9raph</a>
				<!--<ul>
					<li><a href="#"><i class="icon-facebook"></i></a></li>
					<li><a href="#"><i class="icon-twitter"></i></a></li>
					<li><a href="#"><i class="icon-gplus"></i></a></li>
					<li><a href="#"><i class="icon-pinterest"></i></a></li>
					<li><a href="#"><i class="icon-tumblr"></i></a></li>
					<li><a href="#"><i class="icon-instagrem"></i></a></li>
				</ul>-->
			</div>
		</section>
	</div>
</footer>