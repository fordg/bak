<meta charset="utf-8">
<title>HumbleShop</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Metatag -->
<meta property="og:title" content="Baby and Kids" />
<meta property="og:type" content="website" />
<meta property="og:description" content="Perlengkapan Pakaian Balita" />
<meta property="og:url" content="<?php echo base_url(); ?>index.html" />
<meta property="og:image" content="<?php echo base_url(); ?>img/hightreslogo.html" />