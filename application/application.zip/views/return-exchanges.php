<div class="container">
	<section class="page">
		<div class="row">
			<header class="span12 prime">
				<h3>Return Policy</h3>
			</header>
		</div>

		<div class="wrap">
			<div class="row-fluid">
				<div class="span12">
					<h5>Shipping Policy</h5>
                    <p>
                    	1. Barang yang diterima segera di cek ulang. Bila Jangkawaktu 1x24 jam setelah barang diterima tidak ada complain, maka barang yang sudah tidak dapat ditukar lagi.<br />
                        2. Barang retur sudah kami terima maksimal 7 hari setelah complain / mohon maaf jika lewat dari 7 hari kami tidak dapat terima returan barang tersebut.<br />
                        3. Barang yang sudah dipesan tidak dapat ditukar/dikembalikan karena tidak suka warna, model, bahan, kesalahan pemesanan ukuran atau barang tidak sesuai dengan yang diharapkan dengan alasan ini juga tidak dapat diretur.<br />
                    </p>
                    <h5>Refund</h5>
                    <p>
                    	Seluruh barang retur akan kami refund, setelah kami terima barang retur tersebut. Refund akan kami lakukan setiap hari Sabtu.
                    </p>	
				</div>
			</div>
		</div>
	</section>
</div>